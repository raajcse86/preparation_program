package com.learnjava.util;

import java.util.List;

public class DataSet {

    public static List<String> namesList(){
        return List.of("Bob", "Jamie", "Jill", "Rick");

    }
}
